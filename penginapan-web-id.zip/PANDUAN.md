# Panduan Landing Page — penginapan.web.id

Landing page ini dibangun dengan **vanilla HTML5, CSS, dan JavaScript** (tanpa framework), siap diunggah langsung ke domain penginapan.web.id. Struktur folder yang diunggah ke server:

```
/ (root domain)
├── index.html
├── css/style.css
├── js/main.js
├── images/
│   ├── hero-ubud.jpg
│   ├── room-deluxe.jpg
│   ├── room-family.jpg
│   ├── villa-pool.jpg
│   ├── breakfast.jpg
│   ├── location-ubud.jpg
│   └── lounge.jpg
```

## Posisi Halaman (v2 — Cakupan Seluruh Indonesia)

Halaman ini diposisikan sebagai **portal penginapan, villa, dan guesthouse di seluruh Indonesia**, dengan kantor pusat di Jakarta dan unit di enam kota: **Jakarta, Bandung, Yogyakarta, Bali, Surabaya, dan Lombok**. Setiap kota memiliki kartu destinasi dengan harga mulai dan kawasan.

## Yang Sudah Diimplementasikan

### SEO On-Page
| Elemen | Implementasi |
|---|---|
| Title tag | Mengandung keyword "penginapan di Indonesia", villa, guesthouse, akomodasi |
| Meta description | ~160 karakter, cakupan nasional + CTA + harga mulai |
| Heading hierarchy | Satu H1 di hero, H2 per section, H3 untuk kartu kota, kamar, fasilitas, dan FAQ |
| Keyword natural | "penginapan Indonesia", "tempat menginap Indonesia", "villa Indonesia", "homestay Indonesia" tersebar alami |
| Section destinasi | 6 kartu kota (Jakarta, Bandung, Yogyakarta, Bali, Surabaya, Lombok) dengan keyword per-kota |
| Canonical & robots | Canonical ke domain, index/follow dengan max-image-preview |
| Alt text | Semua gambar memiliki deskripsi alt yang deskriptif |

### Geo-Targeting Indonesia
Meta geo nasional (`geo.region` ID, `geo.placename` Indonesia, koordinat tengah Indonesia -2.5489;118.0149, Dublin Core dengan coverage multi-kota), alamat kantor pusat Jakarta dalam schema `PostalAddress`, properti `location` array dengan enam kota dalam schema `LodgingBusiness`, `areaServed` bertipe `Country` (Indonesia), peta Google Maps Jakarta, dan daftar jarak penerbangan ke bandara utama (CGK, HLP, YIA, DPS, SUB, LOP).

### AEO (Answer Engine Optimization)
Section FAQ berisi pertanyaan yang dirumuskan persis seperti query voice/search dengan cakupan nasional: harga per malam (dengan perbandingan antar-kota), kota apa saja yang tersedia, fasilitas umum, cara booking langsung, keluarga, dan check-in/out lintas zona waktu WIB/WITA. Didukung schema `FAQPage` dan schema `LodgingBusiness` dengan `aggregateRating` dan `review`.

### Schema Markup (JSON-LD di `<head>`)
Satu `@graph` berisi: `WebSite`, `Organization` (dengan ContactPoint dan sameAs), `LodgingBusiness` (alamat Jakarta, array location enam kota, areaServed Indonesia, amenityFeature, starRating, priceRange, aggregateRating, review), `BreadcrumbList`, dan `FAQPage`.

### Desain & Aksesibilitas
Desain terinspirasi estetika Latitude Lifestyle: serif klasik untuk judul, sans-serif modern untuk body, palet putih/abu hangat dengan aksen teal, hero foto penuh lebar dengan booking bar melayang, kartu destinasi/kamar dengan harga, section fasilitas, CTA gelap, dan footer empat kolom. Mobile-first responsive (breakpoint 960px dan 600px), skip-link, ARIA labels pada navigasi dan kontrol, `prefers-reduced-motion` dihormati, dan validasi W3C **0 error**.

## Yang HARUS Anda Ganti Sebelum Launch

| Lokasi | Placeholder | Ganti dengan |
|---|---|---|
| `index.html` alamat kantor pusat | `Jl. Sudirman No. 88, Jakarta Pusat` | Alamat kantor pusat asli |
| `index.html` | `+62-812-0000-0000` / `6281200000000` | Nomor WhatsApp/telepon resmi (3 tempat + WhatsApp float) |
| `index.html` | `halo@penginapan.web.id` | Email resmi |
| `index.html` schema | `logo.png` | URL logo asli (unggah ke folder images) |
| `js/main.js` | `phone = "6281200000000"` | Nomor WhatsApp untuk redirect form booking |
| `index.html` | Harga mulai per kota (Rp300rb–Rp550rb) | Harga asli per kota |
| `images/` | Foto AI generik | Foto asli penginapan Anda (nama file bisa dipertahankan) |
| Testimoni | Contoh fiktif | Ulasan tamu asli (penting agar rating schema valid) |
| Map embed | Koordinat Jakarta umum | Koordinat tepat kantor pusat Anda |
| Daftar kota | Jakarta, Bandung, Yogyakarta, Bali, Surabaya, Lombok | Sesuaikan dengan kota yang benar-benar Anda layani |

## Langkah Verifikasi Setelah Upload

1. Uji di [Google Rich Results Test](https://search.google.com/test/rich-results) — pastikan LodgingBusiness, FAQPage, dan Organization terdeteksi.
2. Daftarkan di [Google Search Console](https://search.google.com/search-console), kirim sitemap, dan minta indexing.
3. Buat file `sitemap.xml` dan `robots.txt` di root domain (saya dapat buatkan jika diperlukan).
4. Verifikasi responsivitas dengan browser mobile atau DevTools.
5. Ganti foto dan testimoni fiktif dengan konten asli sebelum traffic organik mulai masuk, agar sesuai kebijakan Google tentang konten yang akurat.
6. Untuk SEO per-kota yang lebih kuat di kemudian hari, pertimbangkan membuat halaman khusus per kota (misalnya `/penginapan-yogyakarta.html`) dan tautkan ke sini — struktur saat ini sudah siap menjadi landing page hub.
